package com.techm.ms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import com.techm.ms.model.User;

@Service("userService")
public class UserServiceImpl implements UserService {
	

private static final AtomicLong counter = new AtomicLong();
	
	private static List<User> users;
	
	static {
		users= populateDummyUsers();
	}

	public List<User> findAllUsers() {
		return users;
	}
	
	public User findById(long id) {
		for(User user : users){
			if(user.getId() == id){
				return user;
			}
		}
		return null;
	}

		
	public void saveUser(User user) {
		counter.incrementAndGet();
		users.add(user);
	}
	
	private static List<User> populateDummyUsers(){
		 List<User> users = new ArrayList<User>();
		users.add(new User(counter.incrementAndGet(), "Tom Hanks",55, 11111));
		users.add(new User(counter.incrementAndGet(), "Will Smith",45, 22222));
		users.add(new User(counter.incrementAndGet(), "Hugh Grant",65, 33333));
		return users;
	}
	
	

	

}
